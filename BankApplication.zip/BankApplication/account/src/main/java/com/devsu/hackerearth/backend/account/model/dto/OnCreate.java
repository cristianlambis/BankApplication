package com.devsu.hackerearth.backend.account.model.dto;

public interface OnCreate {
    
}
