package com.devsu.hackerearth.backend.client.model.dto;

public interface OnUpdate {
    
}